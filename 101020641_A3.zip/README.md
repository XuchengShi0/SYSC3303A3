# 3303_A3

Xucheng Shi 101020641

Four requried files
1. 101020641_Assignment3-------include all the code files from Eclipse
                               Please run the code from host , client then the server
2. Seqence Diagram
3. class Diagram
4. README.md

Q1: Because the UDP for client and server should be proccessed on different thread to avoid block.
Q2: Yes, the host should handle the massage for client and server seperately.